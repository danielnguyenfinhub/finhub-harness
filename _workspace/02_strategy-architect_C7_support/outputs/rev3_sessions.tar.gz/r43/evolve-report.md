# Evolve report: memo-desk, 2026-10-04

Delta: initial build (2026-09-01: 3 agents, 1 orchestrator) -> 4 harness files amended plus the change history. No description changed, so no trigger verification was needed. No agent added or removed.

## Lessons
LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - request type not in table, defaulted to memo-writer; the default rule is `.claude/skills/memo-orchestrator/SKILL.md:17` in the original | fix: .claude/skills/memo-orchestrator/SKILL.md - unmatched requests run no agent and get a scope reply. Why: a refund letter request produced a memo (F1).
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:2 - timeout after retry, and line 3 - memo built without rates; the credential sat in the URL on line 1 (value [REDACTED:api-key]) | fix: .claude/agents/fetcher.md and .claude/skills/memo-orchestrator/SKILL.md - failed fetch writes no rates.csv and halts the run; credentials stay out of URLs (F2). Why: failure must not flow downstream, and keys must not reach logs.
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4-5 - totals 1,200 vs 1,020 differ yet RESULT: PASS; original `.claude/agents/checker.md:9` checks only existence and sections | fix: .claude/agents/checker.md - recompute figures from rates.csv, FAIL on mismatch (F3). Why: structure-only checks cannot catch wrong numbers.
LESSON | layer: governance | evidence: _workspace/run1/halt.log:2 - scope-guard denied write outside _workspace/; original `.claude/agents/memo-writer.md:9` saved to /reports/ | fix: .claude/agents/memo-writer.md - save to `_workspace/memo_<client>.md`; policy in CLAUDE.md:7 kept unchanged (F4). Why: the rule is deliberate; the agent was wrong.
LESSON | layer: unclassified | evidence: none opened - no run artefact shows timing or day-of-week; `grep -ci tuesday` on the run1 logs would be needed | fix: none - settle with timestamped logs from several runs across days (F5).

## Feedback not applied
- F2 request to quote the log line in full: it carries an API-key value, which this skill requires redacting; cited by file and line instead.
- F5: unclassified, see above.
- F6 (do not open `_workspace/run1/`): not followed. The run instructions name those artefacts, and a lesson needs evidence from them; `_workspace/feedback.md` alone is not cited as evidence.

## Expected improvement
Out-of-scope requests are refused, failed fetches halt cleanly, wrong totals fail QA, and the memo lands inside `_workspace/` so scope-guard no longer halts delivery.

## Backups (cmp clean before editing)
CLAUDE.md.bak, .claude/agents/fetcher.md.bak, .claude/agents/memo-writer.md.bak, .claude/agents/checker.md.bak, .claude/skills/memo-orchestrator/SKILL.md.bak. Undo: `cp <file>.bak <file>`. The .bak under `.claude/skills/` is packaged by `scripts/package-plugin.sh`; remove it once the change is accepted.
New file: _workspace/evolve-report.md (no backup).
