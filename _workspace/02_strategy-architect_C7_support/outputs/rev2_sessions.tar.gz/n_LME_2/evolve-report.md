# Evolve report: memo-desk, run1 (2026-10-04)

Evidence base: `_workspace/feedback.md` and the harness files only. Per feedback F6 (feedback.md:10) nothing under `_workspace/run1/` was opened, so the lessons rest on the user's account and are not confirmed against the traces.

## Delta
Initial build (change history in CLAUDE.md) had no failure handling, a catch-all dispatch to memo-writer, a structure-only checker, and a save path outside `_workspace/`.

## Lessons
LESSON | layer: routing | evidence: _workspace/feedback.md:5 - a refund letter request produced a memo; SKILL.md:17 sent every unmatched request to memo-writer | fix: .claude/skills/memo-orchestrator/SKILL.md - unmatched requests are declined and the description lists non-memo documents. Why: a catch-all default hides a mis-route.
LESSON | layer: execution | evidence: _workspace/feedback.md:6 - fetch_rates was called with a URL carrying a credential (value: [REDACTED:api-key]) and the rates never arrived; the cause of the failure is not stated | fix: .claude/agents/fetcher.md and SKILL.md Step 2 - credentials stay out of URLs, a failed fetch writes a redacted `fetch_error.md` and stops the run. Why: the memo-writer must not run without data and the failure must be visible.
LESSON | layer: verification | evidence: _workspace/feedback.md:7 - the QA report said PASS while the memo total was 1,200 instead of 1,020; checker.md:9 checked only existence and section count | fix: .claude/agents/checker.md - recompute totals from rates.csv and FAIL on mismatch. Why: PASS has to mean the numbers are right.
LESSON | layer: governance | evidence: _workspace/feedback.md:8 - the memo-writer's save was stopped; CLAUDE.md:7 forbids writes outside `_workspace/` and memo-writer.md:9 saved to /reports/ | fix: .claude/agents/memo-writer.md, checker.md, SKILL.md - save to `_workspace/<client>.md`. Why: the rule is deliberate, so the agent must comply with it.
LESSON | layer: unclassified | evidence: _workspace/feedback.md:9 - an impression that runs are slower on Tuesdays, with no timings or dates | fix: none - settled by per-step timings with run dates across several runs (for example the dispatch log), which were not opened per F6.

## Not applied
- F5 (Tuesday speed): no evidence of a cause, and a day-specific rule would be overfitting. See the unclassified lesson.
- F2 asked for the log line to be quoted in full. The key in it is redacted by the skill's rule, and the report cites feedback.md:6 instead. The user can check the original there.
- F6 was honoured. It is a request about this run, so it needs no harness change. Recommend re-reading `_workspace/run1/` before trusting the F2 and F3 diagnoses.

## Expected next run
A refund letter is declined; a failed fetch stops with a clear redacted reason; the memo lands in `_workspace/<client>.md`; a wrong total gives FAIL.

## Backups (cmp matched before each edit)
CLAUDE.md.bak, .claude/agents/fetcher.md.bak, memo-writer.md.bak, checker.md.bak, .claude/skills/memo-orchestrator/SKILL.md.bak. No new files except this report. Undo: `cp <file>.bak <file>`. A `.bak` under `skills/` is packaged by `scripts/package-plugin.sh`; remove it once the change is accepted.
