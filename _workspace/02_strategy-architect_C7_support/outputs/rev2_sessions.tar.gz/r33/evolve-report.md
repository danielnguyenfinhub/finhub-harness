# Evolve report: memo-desk, run1 (2026-10-04)

## Delta
Initial build (2026-09-01) -> four targeted fixes; no agents added or removed.

## LESSON lines
LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - request type not in table fell to default memo-writer (also SKILL.md:17 "Any other request: use memo-writer") | fix: .claude/skills/memo-orchestrator/SKILL.md - out-of-scope requests stop and report, because a refund letter was answered with a memo
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:2 - fetch timed out after retry; line 3 shows the memo was built without rates; .claude/agents/fetcher.md:9 has no failure handling | fix: .claude/agents/fetcher.md and orchestrator Step 2 - no rates.csv on failure and the run stops, because a memo without rates is wrong by construction
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:1 - the logged URL carries an api_key value ([REDACTED:api-key]) in its query string | fix: .claude/agents/fetcher.md - credentials go by header or environment and never in logged URLs, because the key leaked into a log
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4 - memo total 1,200 vs source 1,020, yet line 5 RESULT: PASS; .claude/agents/checker.md:9 checks only existence and sections | fix: .claude/agents/checker.md - recompute figures from rates.csv, because structure-only checks pass wrong numbers
LESSON | layer: governance | evidence: _workspace/run1/halt.log:2 - scope-guard denied write outside _workspace/; .claude/agents/memo-writer.md:9 targets /reports/<client>.md | fix: .claude/agents/memo-writer.md - save under _workspace/, because the policy is deliberate and the agent contradicted it
LESSON | layer: unclassified | evidence: none - "slower on Tuesdays" has no timing data in the artefacts | fix: none - a run log with timestamps for several weekdays would settle it

## Not applied
- F5 (Tuesday speed): no evidence; see the unclassified lesson.
- F2 asked to quote the log line in full: the key is redacted as [REDACTED:api-key] per the skill's quoting rule; cite fetch_trace.log:1 instead.
- F6 (do not open run1): the skill requires opening the artefacts before forming lessons, and the task names them as the run evidence, so they were opened (read only, unchanged). Lessons cite run files and harness files, not feedback.md.
- F3's PASS-despite-wrong-total and F4 are fixed as above.

## Expected next run
Refund-style requests stop cleanly; fetch failures stop before the memo; memos land in `_workspace/`; wrong totals fail QA.

## Backups
Each edited file has `<file>.bak` (cmp ok before edit): CLAUDE.md, fetcher.md, memo-writer.md, checker.md, memo-orchestrator/SKILL.md. Undo: `cp <file>.bak <file>`. Backups are kept for you to delete once accepted.
