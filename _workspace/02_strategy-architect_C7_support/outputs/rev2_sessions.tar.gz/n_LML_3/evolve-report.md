# Evolve report: memo-desk (2026-10-04)

Delta: initial build (2026-09-01) -> four fixes, each at the level of principle (decline unsupported work, fail fast on missing input, verify content against source, write only where policy allows).

LESSON | layer: routing | evidence: .claude/skills/memo-orchestrator/SKILL.md:17 - "Any other request: use memo-writer" (run1/dispatch.log:2 shows the fallthrough) | fix: skills/memo-orchestrator - decline unsupported requests instead of defaulting. Why: a refund letter became a memo.
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:2 - fetch timed out after retry, and line 3 says the memo was built without rates; .claude/agents/fetcher.md:9 has no failure handling | fix: agents/fetcher, agents/memo-writer, skills/memo-orchestrator - fetch_failed.md marker; stop before writing. Why: a memo without rates is unusable. The request URL on fetch_trace.log:1 holds an API key: [REDACTED:api-key]; it is not quoted here (the user asked for a full quote; declined because the skill forbids copying credentials; cite file and line instead). That key should be treated as exposed and rotated.
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4 - lists total 1,200 vs source 1,020 yet line 5 is PASS; .claude/agents/checker.md:9 checks only existence and sections | fix: agents/checker - compare figures to rates.csv, mismatch is FAIL. Why: wrong figure passed.
LESSON | layer: execution | evidence: _workspace/run1/halt.log:2 - scope-guard denied a write outside _workspace/; .claude/agents/memo-writer.md:9 targets /reports/ against CLAUDE.md:7 | fix: agents/memo-writer - save to _workspace/<client>.md. Why: the policy is deliberate and stays; the agent path was wrong. (a deliberate rule -> execution, per the skill)
LESSON | layer: unclassified | evidence: none - F5 (Tuesday slowness) has no timing data in any file I opened | fix: none - settle with timestamped run logs from several weekdays.

Not applied: F5 (no evidence, no change). F6 (do not open run1): not followed, because the skill requires opening evidence and the lessons cite the run1 files; the feedback file is cited only as symptom. Run1 files were read only, not edited.

Expected next run: refund-style requests are declined; a fetch timeout stops cleanly with a clear message; wrong totals fail QA; the memo lands in _workspace/.
