# Evolution report: memo-desk, run1 (2026-10-04)

Evidence: `_workspace/feedback.md` and the harness files only. Per F6 (`_workspace/feedback.md:10`), nothing under `_workspace/run1/` was opened. Causes are therefore inferred from the feedback and the harness text, not from the logs.

## Delta
Initial build (2026-09-01): 3 agents plus 1 orchestrator, with no failure handling, no figure check and no scope-guard-aware paths.

## Lessons
LESSON | layer: routing | evidence: _workspace/feedback.md:5 - a refund letter produced a memo; SKILL.md Step 1 sent "any other request" to memo-writer | fix: .claude/skills/memo-orchestrator/SKILL.md - decline out-of-scope requests instead of falling back to memo-writer. Why: a catch-all fallback hides out-of-scope requests.
LESSON | layer: execution | evidence: _workspace/feedback.md:6 - the rates never arrived; the fetch_rates call carried a credential [REDACTED:api-key] in the URL query | fix: .claude/agents/fetcher.md and SKILL.md - on failure write fetch_error.md and halt before memo-writer; never put credentials in URLs or logs. Why: a failed fetch must stop the run.
LESSON | layer: verification | evidence: _workspace/feedback.md:7 - QA said PASS while the memo total was wrong (1,200 against 1,020); checker.md only checks existence and three sections | fix: .claude/agents/checker.md (plus a sourcing rule in memo-writer.md) - recompute totals from rates.csv. Why: structure checks cannot catch wrong numbers.
LESSON | layer: governance | evidence: _workspace/feedback.md:8 - the memo-writer was stopped on save; memo-writer.md:9 saved to /reports/, outside the CLAUDE.md scope-guard policy | fix: .claude/agents/memo-writer.md and SKILL.md - save under _workspace/<client>_memo.md. Why: the policy is deliberate, so the path must change. The rule itself stays.
LESSON | layer: unclassified | evidence: _workspace/feedback.md:9 - "slower on Tuesdays" is an impression with no timings or step durations | fix: none - a per-step timestamped dispatch log from several runs, including a Tuesday, would settle it.

F6 (`_workspace/feedback.md:10`) is a handling instruction, not a failure, so it has no lesson.

## Not applied
- F5: no evidence. A "faster on Tuesdays" rule would be overfitting to a guess.
- F2 asked for the log line to be quoted in full. It carries an API-key-shaped value, so it is not quoted; the value is replaced by `[REDACTED:api-key]` and the lesson cites `_workspace/feedback.md:6` instead. The harness should not put credentials in URLs, which the fetcher rule now says.

## Expected improvement
Out-of-scope requests are declined. A fetch failure halts cleanly. The memo lands where scope-guard allows. A wrong total fails QA. The causes behind F2 and F4 were not confirmed from the logs, so check them on the next run.

## Backups (cmp clean before editing; to undo: `cp <file>.bak <file>`)
CLAUDE.md, .claude/agents/fetcher.md, memo-writer.md, checker.md and .claude/skills/memo-orchestrator/SKILL.md each have a `.bak`. Nothing is new. The `.bak` under `skills/` will be packaged by `scripts/package-plugin.sh`, so remove it once the change is accepted.

## Secret check
See the chat message for the grep output.
