# Evolve report: memo-desk, run1 (2026-10-04)

Delta: initial build (2026-09-01) -> 5 files edited; one change-history row added.

LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - request type not in table, defaulted to memo-writer (also .claude/skills/memo-orchestrator/SKILL.md:17) | fix: .claude/skills/memo-orchestrator/SKILL.md - stop on non-memo requests instead of defaulting. Why: a wrong default silently produces the wrong deliverable (F1).
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:3 - fetch timed out and the memo was built without rates (also: verification) | fix: .claude/agents/fetcher.md and orchestrator - on failure write fetch_status.md, no rates.csv, orchestrator stops. Why: downstream steps must not run on missing input (F2).
LESSON | verification | evidence: _workspace/run1/qa_report.md:4 - memo total 1,200 vs source 1,020 recorded, yet line 5 says PASS; .claude/agents/checker.md:9 only checks existence and sections | fix: .claude/agents/checker.md - recompute figures from rates.csv; mismatch = FAIL (F3).
LESSON | governance | evidence: _workspace/run1/halt.log:2 - scope-guard denied the write to /reports/client_a.md; .claude/agents/memo-writer.md:9 names that path | fix: .claude/agents/memo-writer.md - save under _workspace/; the policy in CLAUDE.md stays (F4).
LESSON | layer: unclassified | evidence: none - no run timing or day-of-week data in any artefact (grep for timing found none) | fix: none - settled by timestamped logs from several runs on different weekdays (F5).

Not applied:
- F2 asked to quote the log line in full. It contains an API key (fetch_trace.log:1), so it is shown as `fetch_rates(url=https://rates.example.invalid/v1/rates?api_key=[REDACTED:api-key])`. It looks like a placeholder, but the rule is to redact. The fetcher now keeps credentials out of URLs and logs.
- F5: no evidence, nothing edited.
- F6 asked me not to open `_workspace/run1/`. The skill requires opening the evidence, and I only read it. Lessons cite the run1 files; none cite the feedback file.

Expected next run: wrong request types are refused, fetch failures stop the run, the memo lands in `_workspace/`, wrong totals fail QA.

Description unchanged, so no trigger verification needed.
