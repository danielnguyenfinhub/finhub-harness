# Evolve report: memo-desk, run1 (2026-10-04)

Delta: initial 3 agents + orchestrator, no failure handling; run1 failed in four places. Four changes applied, one at a time in effect, each generalised to a principle.

LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - unknown request type fell through to memo-writer | fix: skills/memo-orchestrator/SKILL.md - unsupported requests stop with a message (Why: refund letter got a memo)
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:3 - fetch timed out, memo built without rates | fix: agents/fetcher.md + skills/memo-orchestrator/SKILL.md - failed fetch creates no rates.csv and halts the run; credentials via environment, not URL (the URL on line 1 carried an api key, [REDACTED:api-key])
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4-5 - totals 1,200 vs 1,020 yet RESULT: PASS | fix: agents/checker.md - recompute totals from rates.csv, FAIL on mismatch
LESSON | layer: governance | evidence: _workspace/run1/halt.log:2 - scope-guard denied write to /reports/ per CLAUDE.md policy | fix: agents/memo-writer.md - save to _workspace/<client>.md; the policy is correct, the agent path was wrong
LESSON | layer: unclassified | evidence: none - no run artefact shows timing by weekday (feedback.md F5 is a symptom only) | fix: none
 (settling artefact: timestamped logs from several runs on different weekdays)

Not applied:
- F2 request to quote the key line in full: refused; the skill requires redaction. The line is at _workspace/run1/fetch_trace.log:1. The key should be treated as exposed and rotated.
- F5 Tuesday slowness: no evidence, see unclassified lesson.
- F6 "do not open run1": the skill requires opening the evidence, so I did; lessons cite run1 files, not feedback.md.

Expected next run: refund-letter requests are declined, a failed fetch halts cleanly, the memo lands in _workspace/, and wrong totals fail QA.
