# Evolve report: memo-desk (2026-10-04)

Delta: initial build (2026-09-01) -> 4 targeted changes. Evidence is `_workspace/feedback.md` only; `_workspace/run1/` was not opened, per F6 (feedback.md:10).

LESSON | layer: routing | evidence: _workspace/feedback.md:5 - refund letter request produced a memo; SKILL.md:17 defaulted every request to memo-writer | fix: .claude/skills/memo-orchestrator/SKILL.md - decline non-memo requests instead of defaulting. Why: a default route hides mismatches.
LESSON | layer: execution | evidence: _workspace/feedback.md:6 - rates never arrived | fix: .claude/agents/fetcher.md and orchestrator - on failure stop, write no partial file, do not start memo-writer, never echo URLs with credentials. Why: downstream steps need real rates.
LESSON | layer: verification | evidence: _workspace/feedback.md:7 - QA said PASS with a wrong total (1,200 vs 1,020); checker.md:9 checks only existence and sections | fix: .claude/agents/checker.md - recompute totals from rates.csv. Why: a structure check cannot catch a numeric error.
LESSON | layer: governance | evidence: _workspace/feedback.md:8 - save was stopped; CLAUDE.md:5 allows writes only under `_workspace/`, memo-writer.md:9 wrote to /reports/ | fix: .claude/agents/memo-writer.md and orchestrator - save to `_workspace/memo_<client>.md`. Why: honour scope-guard rather than weaken it.
LESSON | layer: unclassified | evidence: _workspace/feedback.md:9 - Tuesday slowness claim, no timing data | fix: none - settled by per-run timestamps from several weekdays.

## Not applied
- F2 asked to quote the log line in full. Not done: it holds an API-key value, which the skill requires redacting as `[REDACTED:api-key]` inside the URL. The line is at feedback.md:6. The user's own copy of the log has the original; the key should be treated as exposed and rotated if it was real.
- F5: no evidence, no change (above).
- F6 honoured: run1 not read, so layer calls rest on the feedback wording alone.

## Backups (cmp clean before edit)
CLAUDE.md.bak, .claude/agents/{fetcher,memo-writer,checker}.md.bak, .claude/skills/memo-orchestrator/SKILL.md.bak. Undo: `cp <file>.bak <file>`. A .bak under skills/ is packaged by scripts/package-plugin.sh; remove it once the change is accepted.
No description changed, so no trigger verification was needed. No new files besides this report.

Expected next run: refund-type requests are declined, fetch failures halt cleanly, memos land in `_workspace/`, wrong totals fail QA.
