# Evolve report: memo-desk, run1 (2026-10-04)

## Delta
Initial build (2026-09-01: 3 agents, 1 orchestrator) -> run1 exposed four defects, all fixed by adjusting existing files. No agents added or removed.

## Lessons
LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - request type not in the table fell through to the default memo-writer | fix: .claude/skills/memo-orchestrator/SKILL.md - unknown requests are declined instead of defaulted. Why: a default agent turns any request into a memo.
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:3 - fetch timed out and the memo was still built without rates | fix: .claude/agents/fetcher.md and memo-orchestrator/SKILL.md - fetcher emits FETCH FAILED and the orchestrator stops. Why: downstream agents must not run on missing input. Also, the key was in the URL at fetch_trace.log:1, so the fetcher now reads credentials from the environment (value not quoted here: [REDACTED:api-key]).
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4 - lists memo total 1,200 vs source 1,020, yet line 5 says PASS | fix: .claude/agents/checker.md - recompute figures from rates.csv and FAIL on mismatch. Why: an existence check cannot catch wrong numbers.
LESSON | layer: execution | evidence: _workspace/run1/halt.log:2 - scope-guard denied the write to /reports/client_a.md; memo-writer.md:9 (original) told it to save there, against CLAUDE.md:7 | fix: .claude/agents/memo-writer.md - save to _workspace/memo_<client>.md. Why: the agent instruction contradicted the project's scope policy. (A tool error caused by a deliberate rule is execution, not governance.)
LESSON | layer: unclassified | evidence: _workspace/feedback.md:9 - the Tuesday slowness claim is unsupported by any run artefact (no timestamps across days) | fix: none - settle with timed traces from several runs on different weekdays.

## Not applied
- F5 (faster on Tuesdays): no evidence; see the unclassified lesson.
- F2's request to quote the log line in full: the skill's rule is to redact credentials, so the key is replaced with [REDACTED:api-key]. Cite `_workspace/run1/fetch_trace.log:1` to check it. The key was exposed in a log and in the feedback file, so rotate it if it is real.
- Opening run1 was not skipped: the skill requires lessons to rest on opened artefacts.
- Out of scope for evolve: none.

## Expected improvement
Refund-style requests get a clear refusal; a fetch failure stops the run; memos land in `_workspace/` so scope-guard no longer halts; wrong totals produce FAIL.
Note: the file path in the checker/orchestrator now includes `memo_<client>.md`; the orchestrator must pass the client name.

## Backups
Each edited file has a `.bak` and `cmp` printed nothing before the edit: CLAUDE.md.bak, .claude/agents/{fetcher,memo-writer,checker}.md.bak, .claude/skills/memo-orchestrator/SKILL.md.bak. Undo: `cp <file>.bak <file>`. `.bak` files under skills/ are packaged by scripts/package-plugin.sh, so remove them once the change is accepted. `_workspace/evolve-report.md` is new, no backup.
