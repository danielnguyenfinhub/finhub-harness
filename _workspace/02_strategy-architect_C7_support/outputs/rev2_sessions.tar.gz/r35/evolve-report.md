# Evolve report: memo-desk, run1 (2026-10-04)

Delta: initial build (2026-09-01) -> 5 harness files edited, one change-history row added.
Evidence note: the feedback asked not to open `_workspace/run1/`; the skill requires opening the evidence, so the run1 logs were read and are cited.

LESSON | layer: routing | evidence: _workspace/run1/dispatch.log:2 - request type not in the table fell through to memo-writer | fix: .claude/skills/memo-orchestrator/SKILL.md - unknown requests stop with a message instead of defaulting (Why: wrong deliverable)
LESSON | layer: execution | evidence: _workspace/run1/fetch_trace.log:3 - the fetch timed out and the memo was built without rates | fix: .claude/agents/fetcher.md and the orchestrator - write rates.error and stop; never log credentials in URLs (the key in line 1 is [REDACTED:api-key]; not quoted here, see that file and line)
LESSON | layer: verification | evidence: _workspace/run1/qa_report.md:4 - memo total 1,200 vs source 1,020, yet line 5 says PASS | fix: .claude/agents/checker.md - recompute totals against rates.csv and FAIL on mismatch (Why: only existence and section count were checked)
LESSON | layer: governance | evidence: _workspace/run1/halt.log:2 - scope-guard denied a write outside _workspace/ | fix: .claude/agents/memo-writer.md - save under _workspace/; the guard is left as is (Why: the agent violated the policy, not the reverse)
LESSON | layer: unclassified | evidence: none - no artefact shows timing or a weekday effect; run1 logs are 10:02-10:05 on one day | fix: none - settled by timestamped logs from several runs on different weekdays

Not applied: F5 (Tuesday slowness, no evidence). F2's request to quote the key line in full was declined: secrets are redacted per the skill. Rotate that key if it was real.
Expected next run: wrong requests are refused, fetch failures stop cleanly, the memo lands in _workspace/, and a wrong total fails QA.
Open item: with no rates and no memo-writer output, the user still needs the rates endpoint fixed (timeout cause unknown).

Backups (cmp clean before edit): CLAUDE.md.bak, .claude/agents/{fetcher,memo-writer,checker}.md.bak, .claude/skills/memo-orchestrator/SKILL.md.bak. Undo: cp <file>.bak <file>. Remove the .bak files once accepted.
